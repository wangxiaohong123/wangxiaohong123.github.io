# Auto-render extension

This is an extension to automatically render all of the math inside of text. It
searches all of the text nodes in a given element for the given delimiters, and
renders the math in place.

See [Auto-render extension documentation](https://katex.org/docs/autorender.html)
for more information.
